$(document).ready(function(){
    $(".sub-btn").click(function(){
       window.location.href = "exchangeResult.html?code=1";
    });
});