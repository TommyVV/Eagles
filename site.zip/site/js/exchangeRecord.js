$(document).ready(function () {
       var str = `<div class="record-item">
       <img src="https://ss2.baidu.com/6ONYsjip0QIZ8tyhnq/it/u=1140382427,1377068190&fm=58&bpow=828&bpoh=643" alt="">
       <div class="record-content">
           <div class="item-title">爱茜茜里甜品面包甜品甜品 面包店30元代金券
           </div>
           <div class="item-time">兑换时间 : 2018-05-11 21:09</div>
       </div>
   </div>`;
   $(".dj-container").html(str+str+str+str+str);
});