$(document).ready(function(){
    $("#subord").click(function(){
       window.location.href = "subordinateList.html";
    });
});