

$(document).ready(function () {
    $(".register").click(function () {
       window.location="./login.html";
    });

});