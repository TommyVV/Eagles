let isMobile = /Android|webOS|iPhone|iPod|BlackBerry/i.test(navigator.userAgent);
console.log(isMobile);