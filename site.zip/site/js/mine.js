$(document).ready(function () {
    //积分换购
    $("#point-part").click(function () {
        window.location.href = 'exchange.html'
    });
    //兑换记录
    $("#record").click(function () {
        window.location.href = "exchangeRecord.html"
    });
    //我的任务
    $("#task").click(function(){
        window.location.href = "task.html"
    });
});