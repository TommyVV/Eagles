$('.toggleTop').on('click', function () {
    $('.toggleContent').toggle('slow');
})